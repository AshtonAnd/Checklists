//
//  ChecklistItem.swift
//  Checklists
//
//  Created by user186046 on 1/24/21.
//  Copyright © 2021 MorsWolfProductions. All rights reserved.
//

import Foundation
class ChecklistItem: NSObject {
    var text = ""
    var checked = false
    
    func toggleChecked() {
     checked.toggle()
    }
}
